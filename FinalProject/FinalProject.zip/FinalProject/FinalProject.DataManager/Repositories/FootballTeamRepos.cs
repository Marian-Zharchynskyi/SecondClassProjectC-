﻿using FinalProject.Core.Context;
using FinalProject.Core.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.DataManager.Repositories
{
    public class FootballTeamRepos
    {
        public IEnumerable<FootballTeam> GetAll()
        {
            using (var ctx = new FootballTeamContext())
            {
                return ctx.FootballTeams.Include(x => x.Coach).ToList();
            }
        }
    }
}
