﻿namespace FinalProject.UI
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBoxCoaches = new ListBox();
            tabControl = new TabControl();
            tabPage1 = new TabPage();
            buttonFindCoach = new Button();
            label10 = new Label();
            textBoxFindCoach = new TextBox();
            buttonEditCoach = new Button();
            buttonRemoveCoach = new Button();
            buttonAddCoach = new Button();
            label9 = new Label();
            pictureBoxCoach = new PictureBox();
            textBoxDrawnMatches = new TextBox();
            textBoxLoosedMatches = new TextBox();
            textBoxWonMatches = new TextBox();
            textBoxCoachCurrentMatches = new TextBox();
            textBoxCoachWonTrofies = new TextBox();
            textBoxCoachAge = new TextBox();
            textBoxCoachFullName = new TextBox();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            tabPage2 = new TabPage();
            label26 = new Label();
            label25 = new Label();
            comboBoxContractCoaches = new ComboBox();
            label23 = new Label();
            dateTimePickerDateEnd = new DateTimePicker();
            label16 = new Label();
            dateTimePickerDateStart = new DateTimePicker();
            buttonFindCoachContract = new Button();
            buttonEditCoachContract = new Button();
            buttonRemoveCoachContract = new Button();
            buttonAddCoachContract = new Button();
            textBoxContractSalary = new TextBox();
            label21 = new Label();
            label1 = new Label();
            textBoxFindCoachContract = new TextBox();
            listBoxCoachesContracts = new ListBox();
            tabPage3 = new TabPage();
            listBoxFootballTeams = new ListBox();
            tabPage4 = new TabPage();
            checkBoxPlayerIsCaptain = new CheckBox();
            buttonFindPlayer = new Button();
            label11 = new Label();
            textBoxFindPlayer = new TextBox();
            buttonEditPlayer = new Button();
            buttonRemovePlayer = new Button();
            buttonAddPlayer = new Button();
            textBoxAssists = new TextBox();
            textBoxPlayerGoals = new TextBox();
            textBoxPlayerWorkingLeg = new TextBox();
            textBoxPlayerAge = new TextBox();
            textBoxPlayerFullName = new TextBox();
            label12 = new Label();
            label14 = new Label();
            label15 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            listBoxPlayers = new ListBox();
            tabPage5 = new TabPage();
            listBoxPlayersContracts = new ListBox();
            tabPage6 = new TabPage();
            listBoxPlayersTransfers = new ListBox();
            tabPage7 = new TabPage();
            listBoxPositions = new ListBox();
            button1 = new Button();
            tabControl.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCoach).BeginInit();
            tabPage2.SuspendLayout();
            tabPage3.SuspendLayout();
            tabPage4.SuspendLayout();
            tabPage5.SuspendLayout();
            tabPage6.SuspendLayout();
            tabPage7.SuspendLayout();
            SuspendLayout();
            // 
            // listBoxCoaches
            // 
            listBoxCoaches.FormattingEnabled = true;
            listBoxCoaches.ItemHeight = 20;
            listBoxCoaches.Location = new Point(-4, 0);
            listBoxCoaches.Name = "listBoxCoaches";
            listBoxCoaches.Size = new Size(1140, 184);
            listBoxCoaches.TabIndex = 0;
            listBoxCoaches.SelectedIndexChanged += listBoxCoaches_SelectedIndexChanged;
            // 
            // tabControl
            // 
            tabControl.Controls.Add(tabPage1);
            tabControl.Controls.Add(tabPage2);
            tabControl.Controls.Add(tabPage3);
            tabControl.Controls.Add(tabPage4);
            tabControl.Controls.Add(tabPage5);
            tabControl.Controls.Add(tabPage6);
            tabControl.Controls.Add(tabPage7);
            tabControl.Location = new Point(0, 2);
            tabControl.Name = "tabControl";
            tabControl.SelectedIndex = 0;
            tabControl.Size = new Size(1508, 684);
            tabControl.TabIndex = 1;
            // 
            // tabPage1
            // 
            tabPage1.BackgroundImageLayout = ImageLayout.Stretch;
            tabPage1.Controls.Add(buttonFindCoach);
            tabPage1.Controls.Add(label10);
            tabPage1.Controls.Add(textBoxFindCoach);
            tabPage1.Controls.Add(buttonEditCoach);
            tabPage1.Controls.Add(buttonRemoveCoach);
            tabPage1.Controls.Add(buttonAddCoach);
            tabPage1.Controls.Add(label9);
            tabPage1.Controls.Add(pictureBoxCoach);
            tabPage1.Controls.Add(textBoxDrawnMatches);
            tabPage1.Controls.Add(textBoxLoosedMatches);
            tabPage1.Controls.Add(textBoxWonMatches);
            tabPage1.Controls.Add(textBoxCoachCurrentMatches);
            tabPage1.Controls.Add(textBoxCoachWonTrofies);
            tabPage1.Controls.Add(textBoxCoachAge);
            tabPage1.Controls.Add(textBoxCoachFullName);
            tabPage1.Controls.Add(label8);
            tabPage1.Controls.Add(label7);
            tabPage1.Controls.Add(label6);
            tabPage1.Controls.Add(label5);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(listBoxCoaches);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1500, 651);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Coaches";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // buttonFindCoach
            // 
            buttonFindCoach.Location = new Point(505, 415);
            buttonFindCoach.Name = "buttonFindCoach";
            buttonFindCoach.Size = new Size(120, 29);
            buttonFindCoach.TabIndex = 24;
            buttonFindCoach.Text = "Find coach";
            buttonFindCoach.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(505, 308);
            label10.Name = "label10";
            label10.Size = new Size(141, 20);
            label10.TabIndex = 23;
            label10.Text = "Find coach by name";
            // 
            // textBoxFindCoach
            // 
            textBoxFindCoach.Location = new Point(505, 337);
            textBoxFindCoach.Multiline = true;
            textBoxFindCoach.Name = "textBoxFindCoach";
            textBoxFindCoach.Size = new Size(120, 61);
            textBoxFindCoach.TabIndex = 22;
            // 
            // buttonEditCoach
            // 
            buttonEditCoach.Location = new Point(341, 417);
            buttonEditCoach.Name = "buttonEditCoach";
            buttonEditCoach.Size = new Size(120, 29);
            buttonEditCoach.TabIndex = 21;
            buttonEditCoach.Text = "Edit coach";
            buttonEditCoach.UseVisualStyleBackColor = true;
            // 
            // buttonRemoveCoach
            // 
            buttonRemoveCoach.Location = new Point(184, 417);
            buttonRemoveCoach.Name = "buttonRemoveCoach";
            buttonRemoveCoach.Size = new Size(120, 29);
            buttonRemoveCoach.TabIndex = 20;
            buttonRemoveCoach.Text = "Remove coach";
            buttonRemoveCoach.UseVisualStyleBackColor = true;
            // 
            // buttonAddCoach
            // 
            buttonAddCoach.Location = new Point(23, 417);
            buttonAddCoach.Name = "buttonAddCoach";
            buttonAddCoach.Size = new Size(120, 29);
            buttonAddCoach.TabIndex = 19;
            buttonAddCoach.Text = "Add new coach";
            buttonAddCoach.UseVisualStyleBackColor = true;
            buttonAddCoach.Click += buttonAddCoach_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(778, 221);
            label9.Name = "label9";
            label9.Size = new Size(94, 20);
            label9.TabIndex = 18;
            label9.Text = "Coach photo";
            // 
            // pictureBoxCoach
            // 
            pictureBoxCoach.Location = new Point(702, 253);
            pictureBoxCoach.Name = "pictureBoxCoach";
            pictureBoxCoach.Size = new Size(230, 215);
            pictureBoxCoach.TabIndex = 17;
            pictureBoxCoach.TabStop = false;
            // 
            // textBoxDrawnMatches
            // 
            textBoxDrawnMatches.Location = new Point(341, 340);
            textBoxDrawnMatches.Multiline = true;
            textBoxDrawnMatches.Name = "textBoxDrawnMatches";
            textBoxDrawnMatches.Size = new Size(98, 34);
            textBoxDrawnMatches.TabIndex = 16;
            // 
            // textBoxLoosedMatches
            // 
            textBoxLoosedMatches.Location = new Point(505, 253);
            textBoxLoosedMatches.Multiline = true;
            textBoxLoosedMatches.Name = "textBoxLoosedMatches";
            textBoxLoosedMatches.Size = new Size(98, 34);
            textBoxLoosedMatches.TabIndex = 15;
            // 
            // textBoxWonMatches
            // 
            textBoxWonMatches.Location = new Point(341, 253);
            textBoxWonMatches.Multiline = true;
            textBoxWonMatches.Name = "textBoxWonMatches";
            textBoxWonMatches.Size = new Size(98, 34);
            textBoxWonMatches.TabIndex = 14;
            // 
            // textBoxCoachCurrentMatches
            // 
            textBoxCoachCurrentMatches.Location = new Point(171, 253);
            textBoxCoachCurrentMatches.Multiline = true;
            textBoxCoachCurrentMatches.Name = "textBoxCoachCurrentMatches";
            textBoxCoachCurrentMatches.Size = new Size(98, 34);
            textBoxCoachCurrentMatches.TabIndex = 13;
            // 
            // textBoxCoachWonTrofies
            // 
            textBoxCoachWonTrofies.Location = new Point(184, 340);
            textBoxCoachWonTrofies.Multiline = true;
            textBoxCoachWonTrofies.Name = "textBoxCoachWonTrofies";
            textBoxCoachWonTrofies.Size = new Size(98, 34);
            textBoxCoachWonTrofies.TabIndex = 12;
            // 
            // textBoxCoachAge
            // 
            textBoxCoachAge.Location = new Point(27, 253);
            textBoxCoachAge.Multiline = true;
            textBoxCoachAge.Name = "textBoxCoachAge";
            textBoxCoachAge.Size = new Size(98, 34);
            textBoxCoachAge.TabIndex = 11;
            // 
            // textBoxCoachFullName
            // 
            textBoxCoachFullName.Location = new Point(23, 340);
            textBoxCoachFullName.Multiline = true;
            textBoxCoachFullName.Name = "textBoxCoachFullName";
            textBoxCoachFullName.Size = new Size(120, 58);
            textBoxCoachFullName.TabIndex = 10;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(341, 308);
            label8.Name = "label8";
            label8.Size = new Size(111, 20);
            label8.TabIndex = 8;
            label8.Text = "Drawn matches";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(505, 221);
            label7.Name = "label7";
            label7.Size = new Size(116, 20);
            label7.TabIndex = 7;
            label7.Text = "Loosed matches";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(341, 221);
            label6.Name = "label6";
            label6.Size = new Size(98, 20);
            label6.TabIndex = 6;
            label6.Text = "Won matches";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(133, 221);
            label5.Name = "label5";
            label5.Size = new Size(171, 20);
            label5.TabIndex = 5;
            label5.Text = "Current matches amount";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(184, 308);
            label4.Name = "label4";
            label4.Size = new Size(85, 20);
            label4.TabIndex = 4;
            label4.Text = "Won trofies";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(53, 221);
            label3.Name = "label3";
            label3.Size = new Size(36, 20);
            label3.TabIndex = 3;
            label3.Text = "Age";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(35, 308);
            label2.Name = "label2";
            label2.Size = new Size(73, 20);
            label2.TabIndex = 2;
            label2.Text = "Full name";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(label26);
            tabPage2.Controls.Add(label25);
            tabPage2.Controls.Add(comboBoxContractCoaches);
            tabPage2.Controls.Add(label23);
            tabPage2.Controls.Add(dateTimePickerDateEnd);
            tabPage2.Controls.Add(label16);
            tabPage2.Controls.Add(dateTimePickerDateStart);
            tabPage2.Controls.Add(buttonFindCoachContract);
            tabPage2.Controls.Add(buttonEditCoachContract);
            tabPage2.Controls.Add(buttonRemoveCoachContract);
            tabPage2.Controls.Add(buttonAddCoachContract);
            tabPage2.Controls.Add(textBoxContractSalary);
            tabPage2.Controls.Add(label21);
            tabPage2.Controls.Add(label1);
            tabPage2.Controls.Add(textBoxFindCoachContract);
            tabPage2.Controls.Add(listBoxCoachesContracts);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1500, 651);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Coaches contracts";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(34, 224);
            label26.Name = "label26";
            label26.Size = new Size(103, 20);
            label26.TabIndex = 80;
            label26.Text = "Choose Coach";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(726, 315);
            label25.Name = "label25";
            label25.Size = new Size(0, 20);
            label25.TabIndex = 79;
            // 
            // comboBoxContractCoaches
            // 
            comboBoxContractCoaches.FormattingEnabled = true;
            comboBoxContractCoaches.Location = new Point(4, 258);
            comboBoxContractCoaches.Name = "comboBoxContractCoaches";
            comboBoxContractCoaches.Size = new Size(168, 28);
            comboBoxContractCoaches.TabIndex = 78;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(420, 311);
            label23.Name = "label23";
            label23.Size = new Size(70, 20);
            label23.TabIndex = 77;
            label23.Text = "Date end";
            // 
            // dateTimePickerDateEnd
            // 
            dateTimePickerDateEnd.Location = new Point(335, 343);
            dateTimePickerDateEnd.Name = "dateTimePickerDateEnd";
            dateTimePickerDateEnd.Size = new Size(250, 27);
            dateTimePickerDateEnd.TabIndex = 76;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(420, 224);
            label16.Name = "label16";
            label16.Size = new Size(74, 20);
            label16.TabIndex = 75;
            label16.Text = "Date start";
            // 
            // dateTimePickerDateStart
            // 
            dateTimePickerDateStart.Location = new Point(335, 256);
            dateTimePickerDateStart.Name = "dateTimePickerDateStart";
            dateTimePickerDateStart.Size = new Size(250, 27);
            dateTimePickerDateStart.TabIndex = 74;
            // 
            // buttonFindCoachContract
            // 
            buttonFindCoachContract.Location = new Point(679, 343);
            buttonFindCoachContract.Name = "buttonFindCoachContract";
            buttonFindCoachContract.Size = new Size(120, 53);
            buttonFindCoachContract.TabIndex = 72;
            buttonFindCoachContract.Text = "Find coach contract";
            buttonFindCoachContract.UseVisualStyleBackColor = true;
            // 
            // buttonEditCoachContract
            // 
            buttonEditCoachContract.Location = new Point(21, 381);
            buttonEditCoachContract.Name = "buttonEditCoachContract";
            buttonEditCoachContract.Size = new Size(120, 50);
            buttonEditCoachContract.TabIndex = 69;
            buttonEditCoachContract.Text = "Edit coach contract";
            buttonEditCoachContract.UseVisualStyleBackColor = true;
            // 
            // buttonRemoveCoachContract
            // 
            buttonRemoveCoachContract.Location = new Point(191, 381);
            buttonRemoveCoachContract.Name = "buttonRemoveCoachContract";
            buttonRemoveCoachContract.Size = new Size(120, 53);
            buttonRemoveCoachContract.TabIndex = 68;
            buttonRemoveCoachContract.Text = "Remove coach contract";
            buttonRemoveCoachContract.UseVisualStyleBackColor = true;
            // 
            // buttonAddCoachContract
            // 
            buttonAddCoachContract.Location = new Point(191, 311);
            buttonAddCoachContract.Name = "buttonAddCoachContract";
            buttonAddCoachContract.Size = new Size(116, 53);
            buttonAddCoachContract.TabIndex = 67;
            buttonAddCoachContract.Text = "Add new coach contract";
            buttonAddCoachContract.UseVisualStyleBackColor = true;
            buttonAddCoachContract.Click += buttonAddCoachContract_Click;
            // 
            // textBoxContractSalary
            // 
            textBoxContractSalary.Location = new Point(191, 256);
            textBoxContractSalary.Multiline = true;
            textBoxContractSalary.Name = "textBoxContractSalary";
            textBoxContractSalary.Size = new Size(133, 34);
            textBoxContractSalary.TabIndex = 61;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(224, 224);
            label21.Name = "label21";
            label21.Size = new Size(49, 20);
            label21.TabIndex = 54;
            label21.Text = "Salary";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(632, 224);
            label1.Name = "label1";
            label1.Size = new Size(199, 20);
            label1.TabIndex = 50;
            label1.Text = "Find coach contract by name";
            // 
            // textBoxFindCoachContract
            // 
            textBoxFindCoachContract.Location = new Point(660, 253);
            textBoxFindCoachContract.Multiline = true;
            textBoxFindCoachContract.Name = "textBoxFindCoachContract";
            textBoxFindCoachContract.Size = new Size(149, 61);
            textBoxFindCoachContract.TabIndex = 49;
            // 
            // listBoxCoachesContracts
            // 
            listBoxCoachesContracts.FormattingEnabled = true;
            listBoxCoachesContracts.ItemHeight = 20;
            listBoxCoachesContracts.Location = new Point(0, 0);
            listBoxCoachesContracts.Name = "listBoxCoachesContracts";
            listBoxCoachesContracts.Size = new Size(1470, 164);
            listBoxCoachesContracts.TabIndex = 1;
            listBoxCoachesContracts.SelectedIndexChanged += listBoxCoachesContracts_SelectedIndexChanged_1;
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(listBoxFootballTeams);
            tabPage3.Location = new Point(4, 29);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(1500, 651);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Football teams";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // listBoxFootballTeams
            // 
            listBoxFootballTeams.FormattingEnabled = true;
            listBoxFootballTeams.ItemHeight = 20;
            listBoxFootballTeams.Location = new Point(8, 3);
            listBoxFootballTeams.Name = "listBoxFootballTeams";
            listBoxFootballTeams.Size = new Size(1484, 164);
            listBoxFootballTeams.TabIndex = 1;
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(checkBoxPlayerIsCaptain);
            tabPage4.Controls.Add(buttonFindPlayer);
            tabPage4.Controls.Add(label11);
            tabPage4.Controls.Add(textBoxFindPlayer);
            tabPage4.Controls.Add(buttonEditPlayer);
            tabPage4.Controls.Add(buttonRemovePlayer);
            tabPage4.Controls.Add(buttonAddPlayer);
            tabPage4.Controls.Add(textBoxAssists);
            tabPage4.Controls.Add(textBoxPlayerGoals);
            tabPage4.Controls.Add(textBoxPlayerWorkingLeg);
            tabPage4.Controls.Add(textBoxPlayerAge);
            tabPage4.Controls.Add(textBoxPlayerFullName);
            tabPage4.Controls.Add(label12);
            tabPage4.Controls.Add(label14);
            tabPage4.Controls.Add(label15);
            tabPage4.Controls.Add(label17);
            tabPage4.Controls.Add(label18);
            tabPage4.Controls.Add(label19);
            tabPage4.Controls.Add(listBoxPlayers);
            tabPage4.Location = new Point(4, 29);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(1500, 651);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "Players";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // checkBoxPlayerIsCaptain
            // 
            checkBoxPlayerIsCaptain.AutoSize = true;
            checkBoxPlayerIsCaptain.Location = new Point(186, 219);
            checkBoxPlayerIsCaptain.Name = "checkBoxPlayerIsCaptain";
            checkBoxPlayerIsCaptain.Size = new Size(18, 17);
            checkBoxPlayerIsCaptain.TabIndex = 45;
            checkBoxPlayerIsCaptain.UseVisualStyleBackColor = true;
            // 
            // buttonFindPlayer
            // 
            buttonFindPlayer.Location = new Point(490, 291);
            buttonFindPlayer.Name = "buttonFindPlayer";
            buttonFindPlayer.Size = new Size(120, 29);
            buttonFindPlayer.TabIndex = 44;
            buttonFindPlayer.Text = "Find player";
            buttonFindPlayer.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(490, 184);
            label11.Name = "label11";
            label11.Size = new Size(145, 20);
            label11.TabIndex = 43;
            label11.Text = "Find Player by Name";
            // 
            // textBoxFindPlayer
            // 
            textBoxFindPlayer.Location = new Point(490, 213);
            textBoxFindPlayer.Multiline = true;
            textBoxFindPlayer.Name = "textBoxFindPlayer";
            textBoxFindPlayer.Size = new Size(120, 61);
            textBoxFindPlayer.TabIndex = 42;
            // 
            // buttonEditPlayer
            // 
            buttonEditPlayer.Location = new Point(343, 380);
            buttonEditPlayer.Name = "buttonEditPlayer";
            buttonEditPlayer.Size = new Size(120, 29);
            buttonEditPlayer.TabIndex = 41;
            buttonEditPlayer.Text = "Edit player";
            buttonEditPlayer.UseVisualStyleBackColor = true;
            // 
            // buttonRemovePlayer
            // 
            buttonRemovePlayer.Location = new Point(186, 380);
            buttonRemovePlayer.Name = "buttonRemovePlayer";
            buttonRemovePlayer.Size = new Size(120, 29);
            buttonRemovePlayer.TabIndex = 40;
            buttonRemovePlayer.Text = "Remove player";
            buttonRemovePlayer.UseVisualStyleBackColor = true;
            // 
            // buttonAddPlayer
            // 
            buttonAddPlayer.Location = new Point(25, 380);
            buttonAddPlayer.Name = "buttonAddPlayer";
            buttonAddPlayer.Size = new Size(134, 29);
            buttonAddPlayer.TabIndex = 39;
            buttonAddPlayer.Text = "Add new player";
            buttonAddPlayer.UseVisualStyleBackColor = true;
            // 
            // textBoxAssists
            // 
            textBoxAssists.Location = new Point(343, 303);
            textBoxAssists.Multiline = true;
            textBoxAssists.Name = "textBoxAssists";
            textBoxAssists.Size = new Size(98, 34);
            textBoxAssists.TabIndex = 38;
            // 
            // textBoxPlayerGoals
            // 
            textBoxPlayerGoals.Location = new Point(343, 216);
            textBoxPlayerGoals.Multiline = true;
            textBoxPlayerGoals.Name = "textBoxPlayerGoals";
            textBoxPlayerGoals.Size = new Size(98, 34);
            textBoxPlayerGoals.TabIndex = 36;
            // 
            // textBoxPlayerWorkingLeg
            // 
            textBoxPlayerWorkingLeg.Location = new Point(186, 303);
            textBoxPlayerWorkingLeg.Multiline = true;
            textBoxPlayerWorkingLeg.Name = "textBoxPlayerWorkingLeg";
            textBoxPlayerWorkingLeg.Size = new Size(98, 34);
            textBoxPlayerWorkingLeg.TabIndex = 34;
            // 
            // textBoxPlayerAge
            // 
            textBoxPlayerAge.Location = new Point(29, 216);
            textBoxPlayerAge.Multiline = true;
            textBoxPlayerAge.Name = "textBoxPlayerAge";
            textBoxPlayerAge.Size = new Size(98, 34);
            textBoxPlayerAge.TabIndex = 33;
            // 
            // textBoxPlayerFullName
            // 
            textBoxPlayerFullName.Location = new Point(25, 303);
            textBoxPlayerFullName.Multiline = true;
            textBoxPlayerFullName.Name = "textBoxPlayerFullName";
            textBoxPlayerFullName.Size = new Size(120, 58);
            textBoxPlayerFullName.TabIndex = 32;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(343, 271);
            label12.Name = "label12";
            label12.Size = new Size(100, 20);
            label12.TabIndex = 31;
            label12.Text = "Assists scored";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(343, 184);
            label14.Name = "label14";
            label14.Size = new Size(94, 20);
            label14.TabIndex = 29;
            label14.Text = "Goals scored";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(212, 213);
            label15.Name = "label15";
            label15.Size = new Size(72, 20);
            label15.TabIndex = 28;
            label15.Text = "Is captain";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(186, 271);
            label17.Name = "label17";
            label17.Size = new Size(89, 20);
            label17.TabIndex = 27;
            label17.Text = "Working leg";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(55, 184);
            label18.Name = "label18";
            label18.Size = new Size(36, 20);
            label18.TabIndex = 26;
            label18.Text = "Age";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(44, 271);
            label19.Name = "label19";
            label19.Size = new Size(73, 20);
            label19.TabIndex = 25;
            label19.Text = "Full name";
            // 
            // listBoxPlayers
            // 
            listBoxPlayers.FormattingEnabled = true;
            listBoxPlayers.ItemHeight = 20;
            listBoxPlayers.Location = new Point(0, 3);
            listBoxPlayers.Name = "listBoxPlayers";
            listBoxPlayers.Size = new Size(1486, 164);
            listBoxPlayers.TabIndex = 1;
            // 
            // tabPage5
            // 
            tabPage5.Controls.Add(listBoxPlayersContracts);
            tabPage5.Location = new Point(4, 29);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(1500, 651);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "Players contracts";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // listBoxPlayersContracts
            // 
            listBoxPlayersContracts.FormattingEnabled = true;
            listBoxPlayersContracts.ItemHeight = 20;
            listBoxPlayersContracts.Location = new Point(3, 6);
            listBoxPlayersContracts.Name = "listBoxPlayersContracts";
            listBoxPlayersContracts.Size = new Size(1482, 164);
            listBoxPlayersContracts.TabIndex = 1;
            // 
            // tabPage6
            // 
            tabPage6.Controls.Add(listBoxPlayersTransfers);
            tabPage6.Location = new Point(4, 29);
            tabPage6.Name = "tabPage6";
            tabPage6.Padding = new Padding(3);
            tabPage6.Size = new Size(1500, 651);
            tabPage6.TabIndex = 5;
            tabPage6.Text = "Players transfers";
            tabPage6.UseVisualStyleBackColor = true;
            // 
            // listBoxPlayersTransfers
            // 
            listBoxPlayersTransfers.FormattingEnabled = true;
            listBoxPlayersTransfers.ItemHeight = 20;
            listBoxPlayersTransfers.Location = new Point(0, 6);
            listBoxPlayersTransfers.Name = "listBoxPlayersTransfers";
            listBoxPlayersTransfers.Size = new Size(1494, 164);
            listBoxPlayersTransfers.TabIndex = 1;
            // 
            // tabPage7
            // 
            tabPage7.Controls.Add(listBoxPositions);
            tabPage7.Location = new Point(4, 29);
            tabPage7.Name = "tabPage7";
            tabPage7.Padding = new Padding(3);
            tabPage7.Size = new Size(1500, 651);
            tabPage7.TabIndex = 6;
            tabPage7.Text = "Positions";
            tabPage7.UseVisualStyleBackColor = true;
            // 
            // listBoxPositions
            // 
            listBoxPositions.FormattingEnabled = true;
            listBoxPositions.ItemHeight = 20;
            listBoxPositions.Location = new Point(6, 6);
            listBoxPositions.Name = "listBoxPositions";
            listBoxPositions.Size = new Size(1486, 124);
            listBoxPositions.TabIndex = 1;
            // 
            // button1
            // 
            button1.Location = new Point(323, 329);
            button1.Name = "button1";
            button1.Size = new Size(120, 52);
            button1.TabIndex = 46;
            button1.Text = "Find coach contract";
            button1.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1508, 686);
            Controls.Add(tabControl);
            Name = "MainForm";
            Text = "User Form";
            tabControl.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCoach).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            tabPage3.ResumeLayout(false);
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            tabPage5.ResumeLayout(false);
            tabPage6.ResumeLayout(false);
            tabPage7.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private ListBox listBoxCoaches;
        private TabControl tabControl;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private TabPage tabPage5;
        private TabPage tabPage6;
        private TabPage tabPage7;
        private ListBox listBoxCoachesContracts;
        private ListBox listBoxFootballTeams;
        private ListBox listBoxPlayers;
        private ListBox listBoxPlayersContracts;
        private ListBox listBoxPlayersTransfers;
        private ListBox listBoxPositions;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox textBoxCoachCurrentMatches;
        private TextBox textBoxCoachWonTrofies;
        private TextBox textBoxCoachAge;
        private TextBox textBoxCoachFullName;
        private TextBox textBoxDrawnMatches;
        private TextBox textBoxLoosedMatches;
        private TextBox textBoxWonMatches;
        private Label label9;
        private PictureBox pictureBoxCoach;
        private Button buttonEditCoach;
        private Button buttonRemoveCoach;
        private Button buttonAddCoach;
        private Button buttonFindCoach;
        private Label label10;
        private TextBox textBoxFindCoach;
        private Button button1;
        private PictureBox pictureBox1;
        private TextBox textBoxPlayerGoals;
        private TextBox textBoxPlayerAge;
        private DateTimePicker dateTimePickerStartDate;
        private Label label1;
        private TextBox textBoxFindCoachContract;
        private Button buttonFindCoachContract;
        private Button buttonEditCoachContract;
        private Button buttonRemoveCoachContract;
        private Button buttonAddCoachContract;
        private TextBox textBoxPlayerWorkingLeg;
        private TextBox textBoxPlayerFullName;
        private TextBox textBox9;
        private TextBox textBoxContractSalary;
        private TextBox textBox11;
        private TextBox textBox13;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label labelCContract;
        private Label label24;
        private Label label23;
        private DateTimePicker dateTimePickerDateEnd;
        private Label label16;
        private DateTimePicker dateTimePickerDateStart;
        private ComboBox comboBoxContractCoaches;
        private Label label26;
        private Label label25;
        private Button buttonFindPlayer;
        private Label label11;
        private TextBox textBoxFindPlayer;
        private Button buttonEditPlayer;
        private Button buttonRemovePlayer;
        private Button buttonAddPlayer;
        private TextBox textBoxAssists;
        private Label label12;
        private Label label14;
        private Label label15;
        private Label label17;
        private CheckBox checkBoxPlayerIsCaptain;
    }
}