﻿using FinalProject.Core.Context;
using FinalProject.Core.Entities;
using FinalProject.DataManager.Repositories;
using Microsoft.EntityFrameworkCore;

namespace FinalProject.UI
{
    public partial class MainForm : Form
    {
        private CoachRep _coachRepos = new CoachRep();
        private CoachContractRep _coachContractRepos = new CoachContractRep();
        private FootballTeamRepos _footballTeamRepos = new FootballTeamRepos();
        private PlayerRep _playerRepos = new PlayerRep();
        private PlayerContractRep _playerContractRepos = new PlayerContractRep();
        private PlayerTransferRep _playerTransferRepos = new PlayerTransferRep();
        private PositionRep _positionRep = new PositionRep();
        public MainForm()
        {
            InitializeComponent();
            listBoxCoaches.Items.AddRange(_coachRepos.GetAll().ToArray());
            listBoxCoachesContracts.Items.AddRange(_coachContractRepos.GetAll().ToArray());
            listBoxFootballTeams.Items.AddRange(_footballTeamRepos.GetAll().ToArray());
            listBoxPlayers.Items.AddRange(_playerRepos.GetAll().ToArray());
            listBoxPlayersContracts.Items.AddRange(_playerContractRepos.GetAll().ToArray());
            listBoxPlayersTransfers.Items.AddRange(_playerTransferRepos.GetAll().ToArray());
            listBoxPositions.Items.AddRange(_positionRep.GetAll().ToArray());

            checkRole(PersonalData.IsAdmin);


            var coaches = _coachRepos.GetAll();

            comboBoxContractCoaches.DataSource = coaches.ToList();
            comboBoxContractCoaches.DisplayMember = "FullName"; // Відображати ім'я тренера в comboBox
            comboBoxContractCoaches.ValueMember = "Id";
        }

        private void checkRole(bool role)
        {
            switch (role)
            {
                case (true):

                    MessageBox.Show($"Welcome {PersonalData.Login}", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;

                case (false):

                    MessageBox.Show($"Welcome {PersonalData.Login}", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;

                default:
                    MessageBox.Show("User hasn't founded", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;
            }
        }

        private void buttonAddCoach_Click(object sender, EventArgs e)
        {
            string fullName = textBoxCoachFullName.Text;
            int age = Convert.ToInt32(textBoxCoachAge.Text);
            int wonTrofies = Convert.ToInt32(textBoxCoachWonTrofies.Text);
            int currentMatches = Convert.ToInt32(textBoxCoachCurrentMatches.Text);
            int drawnMatches = Convert.ToInt32(textBoxDrawnMatches.Text);
            int wonMatches = Convert.ToInt32(textBoxWonMatches.Text);
            int loosedMatches = Convert.ToInt32(textBoxLoosedMatches.Text);

            // Створюємо новий об'єкт тренера
            Coach newCoach = new Coach
            {
                FullName = fullName,
                Age = age,
                WonTrofies = wonTrofies,
                CurrentMatchesAmount = currentMatches,
                DrawnMatches = drawnMatches,
                WonMatches = wonMatches,
                LoosedMatches = loosedMatches
            };

            // Викликаємо метод Add з CoachRep для додавання тренера в базу даних
            int addedCoachId = _coachRepos.Add(newCoach);

            // Виводимо повідомлення про успішне додавання або оброблюємо інші взаємодії
            if (addedCoachId > 0)
            {
                MessageBox.Show($"Coach with ID {addedCoachId} has been successfully added.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Оновлюємо список тренерів чи інші взаємодії
                UpdateCoachList();
            }
            else
            {
                MessageBox.Show("Failed to add coach.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateCoachList()
        {
            listBoxCoaches.Items.Clear();
            listBoxCoaches.Items.AddRange(_coachRepos.GetAll().ToArray());
        }

        private void listBoxCoaches_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxCoaches.SelectedIndex != -1)
            {
                // Отримуємо об'єкт тренера, який відповідає вибраному рядку
                Coach selectedCoach = (Coach)listBoxCoaches.SelectedItem;

                // Виводимо дані тренера у текстові поля
                textBoxCoachFullName.Text = selectedCoach.FullName;
                textBoxCoachAge.Text = selectedCoach.Age.ToString();
                textBoxCoachWonTrofies.Text = selectedCoach.WonTrofies.ToString();
                textBoxCoachCurrentMatches.Text = selectedCoach.CurrentMatchesAmount.ToString();
                textBoxDrawnMatches.Text = selectedCoach.DrawnMatches.ToString();
                textBoxWonMatches.Text = selectedCoach.WonMatches.ToString();
                textBoxLoosedMatches.Text = selectedCoach.LoosedMatches.ToString();
            }
        }

        private void buttonAddCoachContract_Click(object sender, EventArgs e)
        {
            int coachId = Convert.ToInt32(comboBoxContractCoaches.SelectedValue);


            if (comboBoxContractCoaches.SelectedIndex == -1)
            {
                MessageBox.Show("Choose coach", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            var ctx = new FootballTeamContext();

            var coach = ctx.Coaches.First(x => x.Id == Convert.ToInt32(comboBoxContractCoaches.SelectedValue));

            ctx.CoachContracts.Add(new CoachContract
            {
                Coach = coach,
                StartDate = dateTimePickerDateStart.Value,
                EndDate = dateTimePickerDateEnd.Value,
                Salary = Convert.ToInt32(textBoxContractSalary.Text)
            });

            ctx.SaveChanges();

            UpdateCoachContractList();
        }

        private void listBoxCoachesContracts_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            var selectedContract = (CoachContract)listBoxCoachesContracts.SelectedItem;

            // Перевірити, чи обраний контракт не є нульовим
            if (selectedContract != null)
            {
                // Вивести дані контракту тренера у відповідні UI елементи
                textBoxContractSalary.Text = selectedContract.Salary.ToString();
                comboBoxContractCoaches.SelectedValue = selectedContract.Coach.Id;
                dateTimePickerDateStart.Value = selectedContract.StartDate;
                dateTimePickerDateEnd.Value = selectedContract.EndDate;
            }
        }

        private void UpdateCoachContractList()
        {
            listBoxCoachesContracts.Items.Clear();
            listBoxCoachesContracts.Items.AddRange(_coachContractRepos.GetAll().ToArray());

        }


        private void buttonAddPlayer_Click(object sender, EventArgs e)
        {

        }

    }
}
