﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.UI
{
    public class DB
    {

        public string stringCon()
        {
            return "Server=.;Database=Football_Team;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

        }
    }
}
